package com.example;

import java.util.Scanner;

public class App{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter email content to scan: ");
        String emailContent = scanner.nextLine();
        try {
            EmailScanner emailScanner = new EmailScanner();
            int suspicionPercentage = emailScanner.scanEmail(emailContent);
            System.out.println("Suspicion Percentage: " + suspicionPercentage + "%");
        } catch (EmailScanningException e) {
            System.err.println("Error scanning email: " + e.getMessage());
        }
        scanner.close();
    }
}