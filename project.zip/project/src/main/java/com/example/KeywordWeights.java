package com.example;

import java.util.HashMap;
import java.util.Map;

public class KeywordWeights {
    private Map<String, Integer> weights;

    public KeywordWeights() {
        weights = new HashMap<>();
        weights.put("phishing", 50);
        weights.put("personal_info", 30);
        weights.put("suspicious_links", 20);
    }

    public int getWeight(String keywordType) {
        return weights.getOrDefault(keywordType, 0);
    }

    public void setWeight(String keywordType, int weight) {
        weights.put(keywordType, weight);
    }
}