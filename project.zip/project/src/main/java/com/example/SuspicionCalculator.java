package com.example;

class SuspicionCalculator {
    private KeywordWeights keywordWeights;

    public SuspicionCalculator() {
        keywordWeights = new KeywordWeights();
    }

    public int calculateSuspicion(String emailContent) {
        int suspicionScore = 0;
        if (containsPhishingKeywords(emailContent)) {
            suspicionScore += keywordWeights.getWeight("phishing");
        }
        if (containsPersonalInformationRequest(emailContent)) {
            suspicionScore += keywordWeights.getWeight("personal_info");
        }
        if (containsSuspiciousLinks(emailContent)) {
            suspicionScore += keywordWeights.getWeight("suspicious_links");
        }
        return Math.min(suspicionScore, 100);
    }

    boolean containsPhishingKeywords(String emailContent) {
        String[] phishingKeywords = {"urgent", "immediate action", "click here", "free prize", "limited time"};
        for (String keyword : phishingKeywords) {
            if (emailContent.toLowerCase().contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    boolean containsPersonalInformationRequest(String emailContent) {
        String[] personalInfoKeywords = {"ssn", "social security number", "password", "credit card", "account number"};
        for (String keyword : personalInfoKeywords) {
            if (emailContent.toLowerCase().contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    boolean containsSuspiciousLinks(String emailContent) {
        return emailContent.contains("http://") || emailContent.contains("https://");
    }
}