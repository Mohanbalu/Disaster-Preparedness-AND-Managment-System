package com.example;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class KeywordDAO {
    private Connection connection;

    public KeywordDAO() throws SQLException {
        this(DriverManager.getConnection("jdbc:postgresql://localhost:5432/EmailScanningSystem", "postgree", "2004"));
    }

    public KeywordDAO(Connection connection) {
        this.connection = connection;
    }

    public void addKeyword(String keyword, int weight) throws SQLException {
        if (keyword == null || keyword.trim().isEmpty()) {
            throw new SQLException("Keyword cannot be null or empty");
        }
        String query = "INSERT INTO Keywords (keyword, weight) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, keyword);
        preparedStatement.setInt(2, weight);
        preparedStatement.executeUpdate();
    }

    public Map<String, Integer> getAllKeywords() throws SQLException {
        Map<String, Integer> keywords = new HashMap<>();
        String query = "SELECT keyword, weight FROM Keywords";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            keywords.put(resultSet.getString("keyword"), resultSet.getInt("weight"));
        }

        return keywords;
    }

    public void updateKeywordWeight(String keyword, int newWeight) throws SQLException {
        if (keyword == null || keyword.trim().isEmpty()) {
            throw new SQLException("Keyword cannot be null or empty");
        }
        String query = "UPDATE Keywords SET weight = ? WHERE keyword = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, newWeight);
        preparedStatement.setString(2, keyword);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected == 0) {
            throw new SQLException("Keyword not found");
        }
    }

    public void deleteKeyword(String keyword) throws SQLException {
        if (keyword == null || keyword.trim().isEmpty()) {
            throw new SQLException("Keyword cannot be null or empty");
        }
        String query = "DELETE FROM Keywords WHERE keyword = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, keyword);
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected == 0) {
            throw new SQLException("Keyword not found");
        }
    }
}