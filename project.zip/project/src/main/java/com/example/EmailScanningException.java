package com.example;

public class EmailScanningException extends Exception {
    public EmailScanningException(String message) {
        super(message);
    }
}