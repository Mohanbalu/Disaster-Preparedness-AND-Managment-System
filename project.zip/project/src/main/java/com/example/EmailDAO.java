package com.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmailDAO {
    private Connection connection;

    public EmailDAO() throws SQLException {
        this(DriverManager.getConnection("jdbc:postgresql://localhost:5432/EmailScanningSystem", "postgree", "2004"));
    }

    public EmailDAO(Connection connection) {
        this.connection = connection;
    }

    public void addEmail(String content, int suspicionScore) throws SQLException {
        String query = "INSERT INTO Emails (content, suspicion_score) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, content);
        preparedStatement.setInt(2, suspicionScore);
        preparedStatement.executeUpdate();
    }

    public List<String> getAllEmails() throws SQLException {
        List<String> emails = new ArrayList<>();
        String query = "SELECT content FROM Emails";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        while (resultSet.next()) {
            emails.add(resultSet.getString("content"));
        }

        return emails;
    }
}