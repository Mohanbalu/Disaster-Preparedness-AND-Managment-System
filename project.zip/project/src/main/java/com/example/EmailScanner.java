package com.example;

public class EmailScanner {
    private SuspicionCalculator suspicionCalculator;

    public EmailScanner() {
        this.suspicionCalculator = new SuspicionCalculator();
    }

    public int scanEmail(String emailContent) throws EmailScanningException {
        if (emailContent == null || emailContent.trim().isEmpty()) {
            throw new EmailScanningException("Email content cannot be null or empty");
        }
        return suspicionCalculator.calculateSuspicion(emailContent);
    }
}