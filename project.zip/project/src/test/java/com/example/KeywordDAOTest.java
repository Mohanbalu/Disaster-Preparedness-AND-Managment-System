package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class KeywordDAOTest {
    private Connection connection;
    private KeywordDAO keywordDAO;

    @Before
    public void setUp() throws SQLException {
        // Set up in-memory H2 database
        connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        keywordDAO = new KeywordDAO(connection);

        // Create the Keywords table
        createKeywordsTable();
    }

    @After
    public void tearDown() throws SQLException {
        // Drop the Keywords table and close connection
        dropKeywordsTable();
        connection.close();
    }

    private void createKeywordsTable() throws SQLException {
        connection.createStatement().execute("CREATE TABLE IF NOT EXISTS Keywords (keyword VARCHAR(255), weight INT)");
    }

    private void dropKeywordsTable() throws SQLException {
        connection.createStatement().execute("DROP TABLE IF EXISTS Keywords");
    }

    @Test
    public void testAddKeyword() throws SQLException {
        keywordDAO.addKeyword("testKeyword", 25);

        Map<String, Integer> keywords = keywordDAO.getAllKeywords();
        assertEquals(1, keywords.size());
        assertTrue(keywords.containsKey("testKeyword"));
        assertEquals(Integer.valueOf(25), keywords.get("testKeyword"));
    }

    @Test
    public void testGetAllKeywords() throws SQLException {
        keywordDAO.addKeyword("testKeyword1", 10);
        keywordDAO.addKeyword("testKeyword2", 20);

        Map<String, Integer> keywords = keywordDAO.getAllKeywords();
        assertEquals(2, keywords.size());
        assertEquals(Integer.valueOf(10), keywords.get("testKeyword1"));
        assertEquals(Integer.valueOf(20), keywords.get("testKeyword2"));
    }

    @Test
    public void testUpdateKeywordWeight() throws SQLException {
        keywordDAO.addKeyword("testKeyword", 25);

        keywordDAO.updateKeywordWeight("testKeyword", 30);

        Map<String, Integer> keywords = keywordDAO.getAllKeywords();
        assertEquals(Integer.valueOf(30), keywords.get("testKeyword"));
    }

    @Test
    public void testDeleteKeyword() throws SQLException {
        keywordDAO.addKeyword("testKeyword", 25);

        keywordDAO.deleteKeyword("testKeyword");

        Map<String, Integer> keywords = keywordDAO.getAllKeywords();
        assertTrue(keywords.isEmpty());
    }

    @Test(expected = SQLException.class)
    public void testAddKeywordWithNullValue() throws SQLException {
        keywordDAO.addKeyword(null, 25);
    }

    @Test(expected = SQLException.class)
    public void testAddKeywordWithEmptyValue() throws SQLException {
        keywordDAO.addKeyword("", 25);
    }

    @Test(expected = SQLException.class)
    public void testUpdateKeywordWeightWithNullValue() throws SQLException {
        keywordDAO.updateKeywordWeight(null, 30);
    }

    @Test(expected = SQLException.class)
    public void testUpdateKeywordWeightWithEmptyValue() throws SQLException {
        keywordDAO.updateKeywordWeight("", 30);
    }

    @Test(expected = SQLException.class)
    public void testUpdateNonExistentKeyword() throws SQLException {
        keywordDAO.updateKeywordWeight("nonExistentKeyword", 30);
    }

    @Test(expected = SQLException.class)
    public void testDeleteKeywordWithNullValue() throws SQLException {
        keywordDAO.deleteKeyword(null);
    }

    @Test(expected = SQLException.class)
    public void testDeleteKeywordWithEmptyValue() throws SQLException {
        keywordDAO.deleteKeyword("");
    }

    @Test(expected = SQLException.class)
    public void testDeleteNonExistentKeyword() throws SQLException {
        keywordDAO.deleteKeyword("nonExistentKeyword");
    }

    @Test(expected = SQLException.class)
    public void testAddKeywordWithSQLException() throws SQLException {
        // Drop Keywords table to force SQLException when adding keyword
        dropKeywordsTable();
        keywordDAO.addKeyword("testKeyword", 25);
    }
}