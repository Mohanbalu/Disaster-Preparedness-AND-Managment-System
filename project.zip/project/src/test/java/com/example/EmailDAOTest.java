package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class EmailDAOTest {
    private Connection connection;
    private EmailDAO emailDAO;

    @Before
    public void setUp() throws SQLException {
        // Set up in-memory H2 database
        connection = DriverManager.getConnection("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        emailDAO = new EmailDAO(connection);

        // Create the Emails table
        connection.createStatement().execute("CREATE TABLE Emails (content VARCHAR(255), suspicion_score INT)");
    }

    @After
    public void tearDown() throws SQLException {
        // Drop the Emails table and close connection
        connection.createStatement().execute("DROP TABLE Emails");
        connection.close();
    }

    @Test
    public void testAddEmail() throws SQLException {
        emailDAO.addEmail("testContent", 75);

        List<String> emails = emailDAO.getAllEmails();
        assertEquals(1, emails.size());
        assertTrue(emails.contains("testContent"));
    }

    @Test
    public void testGetAllEmails() throws SQLException {
        emailDAO.addEmail("testContent1", 40);
        emailDAO.addEmail("testContent2", 60);

        List<String> emails = emailDAO.getAllEmails();
        assertEquals(2, emails.size());
        assertTrue(emails.contains("testContent1"));
        assertTrue(emails.contains("testContent2"));
    }

    @Test(expected = SQLException.class)
    public void testAddEmailWithSQLException() throws SQLException {
        // Test with an invalid SQL statement to force an SQLException
        connection.createStatement().execute("DROP TABLE Emails");
        emailDAO.addEmail("testContent", 75);
    }
}