package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class AppTest {
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setErr(originalErr);
    }

    @Test
    public void testMainWithNormalContent() {
        String input = "Hello, this is a normal email content.\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        App.main(new String[0]);
        String expectedOutput = "Enter email content to scan: \nSuspicion Percentage: 0%\n";
        assertEquals(expectedOutput, outContent.toString());
        assertEquals("", errContent.toString());
    }

    @Test
    public void testMainWithSuspiciousContent() {
        String input = "Urgent! Click here for a free prize.\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        App.main(new String[0]);
        String expectedOutput = "Enter email content to scan: \nSuspicion Percentage: 50%\n";
        assertEquals(expectedOutput, outContent.toString());
        assertEquals("", errContent.toString());
    }

    @Test
    public void testMainWithEmptyContent() {
        String input = "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        App.main(new String[0]);
        String expectedOutput = "Enter email content to scan: \n";
        String expectedError = "Error scanning email: Email content cannot be null or empty\n";
        assertEquals(expectedOutput, outContent.toString());
        assertEquals(expectedError, errContent.toString());
    }

    @Test
    public void testMainWithWhitespaceContent() {
        String input = " \n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        App.main(new String[0]);
        String expectedOutput = "Enter email content to scan: \n";
        String expectedError = "Error scanning email: Email content cannot be null or empty\n";
        assertEquals(expectedOutput, outContent.toString());
        assertEquals(expectedError, errContent.toString());
    }

    @Test
    public void testMainWithMultiLineInput() {
        String input = "Hello\nworld\nsuspicious\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        App.main(new String[0]);
        String expectedOutput = "Enter email content to scan: \nSuspicion Percentage: 0%\n";
        assertEquals(expectedOutput, outContent.toString());
        assertEquals("", errContent.toString());
    }

    @Test
    public void testMainWithExceptionFlow() {
        try {
            new EmailScanner().scanEmail(null);
            fail("Expected EmailScanningException to be thrown");
        } catch (EmailScanningException e) {
            assertEquals("Email content cannot be null or empty", e.getMessage());
        }
    }

    @Test
    public void testEmailScannerWithNoSuspicion() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        int suspicionPercentage = emailScanner.scanEmail("Hello, this is a normal email content.");
        assertEquals(0, suspicionPercentage);
    }

    @Test
    public void testEmailScannerWithPhishingKeywords() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        int suspicionPercentage = emailScanner.scanEmail("Urgent! Click here for a free prize.");
        assertEquals(50, suspicionPercentage);
    }

    @Test
    public void testEmailScannerWithPersonalInfoRequest() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        int suspicionPercentage = emailScanner.scanEmail("Please provide your Social Security Number (SSN).");
        assertEquals(30, suspicionPercentage);
    }

    @Test
    public void testEmailScannerWithSuspiciousLinks() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        int suspicionPercentage = emailScanner.scanEmail("Visit http://example.com for more details.");
        assertEquals(20, suspicionPercentage);
    }

    @Test
    public void testEmailScannerWithAllSuspicionFactors() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        int suspicionPercentage = emailScanner.scanEmail("Urgent! Click here and visit http://example.com for a limited time offer. Provide your Social Security Number.");
        assertEquals(100, suspicionPercentage); // Ensure it doesn't exceed 100%
    }

    @Test
    public void testContainsPhishingKeywords() {
        SuspicionCalculator calculator = new SuspicionCalculator();
        assertEquals(true, calculator.containsPhishingKeywords("urgent action needed"));
        assertEquals(false, calculator.containsPhishingKeywords("normal email content"));
    }

    @Test
    public void testContainsPersonalInformationRequest() {
        SuspicionCalculator calculator = new SuspicionCalculator();
        assertEquals(true, calculator.containsPersonalInformationRequest("Please provide your credit card number"));
        assertEquals(false, calculator.containsPersonalInformationRequest("normal email content"));
    }

    @Test
    public void testContainsSuspiciousLinks() {
        SuspicionCalculator calculator = new SuspicionCalculator();
        assertEquals(true, calculator.containsSuspiciousLinks("Visit https://example.com"));
        assertEquals(false, calculator.containsSuspiciousLinks("normal email content"));
    }

    @Test(expected = EmailScanningException.class)
    public void testEmailScannerWithEmptyEmailContent() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        emailScanner.scanEmail("");
    }

    @Test(expected = EmailScanningException.class)
    public void testEmailScannerWithNullEmailContent() throws EmailScanningException {
        EmailScanner emailScanner = new EmailScanner();
        emailScanner.scanEmail(null);
    }

    @Test
    public void testCustomKeywordWeights() {
        KeywordWeights keywordWeights = new KeywordWeights();
        keywordWeights.setWeight("test_keyword", 15);
        assertEquals(15, keywordWeights.getWeight("test_keyword"));
    }
}